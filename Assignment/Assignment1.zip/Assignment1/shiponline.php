<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Ship Online System</title>
<meta name="ShipOnline" />
<meta name="Tran Ha" />
<meta name="viewport" content="width=device-width, maximum-scale=1.0, user-scalable=2.0;" />
<link rel="stylesheet" href="styles/style.css" />
</head>

<div>
  <header>
    <h1> ShipOnline System Home Page </h1>
  </header>
  <nav>
  <fieldset>
    <p> New users: <a href="register.php">Registration</a> </p>
    <p> Existing users: <a href="login.php">Log-In</a> </p>
    <p> Administrations: <a href="admin.php">Administration</a> </p>
    </fieldset>
  </nav>
  <footer>
    
  </footer>
</div>
</body></html>