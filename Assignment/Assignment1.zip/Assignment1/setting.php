<?php
//$host = "mysql.ict.swin.edu.au";
//$user ="s4959353";// your user name
//$pwd ="260282";// your password (ddmmyyunless  changed)
//$sql_db="s4959353_db";// your data  
$host = "localhost";
$user ="root";// your user name
$pwd ="root";// your password (ddmmyyunless  changed)
$sql_db="s4959353_db";// your data  
?>