1/ List files
Assignment1
—images
--—-error.png	
---—success.png
-js
————adminFrm.js
————jquery-1.11.1.min.js
————requestFrm.js
————script.js
-sqlQuery
————customer.sql
————request.sql
-styles
————style.css
admin.php
login.php
register.php
request.php
setting.php
shiponline.php

— HOW TO USE -

open SHIPONLINE.php which is the HOME PAGE