
//
//<?php
//    echo "var jsArray = new Array();";
//    foreach ($_POST as $key=>$value){
//        echo "jsArray['$key'] = '$value';";  //turn it into a javascript array
//    }
//?>
//
//
//        // Grab all elements that have tagname input
//        var inputArr = document.getElementsByTagName("input");
//
//        // Loop through those elements and fill in data
//        for (var i = 0; i < inputArr.length; i++){
//            inputArr[i].value = jsArray[inputArr[i].name];
//
//        }
//
